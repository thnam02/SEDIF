export const copyVi = {
  brand: 'FIDES', close: 'Đóng', confirm: 'Xác nhận', cancel: 'Huỷ giao dịch', continue: 'Tiếp tục', allow: 'Cho phép', later: 'Để sau', money: '120.000.000 đ', recipient: 'LE THI C',
  info: { title: 'Xác nhận chuyển tiền', note: 'FIDES đang giúp bạn kiểm tra giao dịch này.', content: 'Nội dung: Chuyển tiền' },
  banner: { title: 'Hãy cẩn thận', body: 'Nếu ai đó đang hướng dẫn bạn chuyển tiền qua điện thoại, hãy dừng lại và kiểm tra.' },
  simo: 'Tài khoản nhận đã bị báo cáo có dấu hiệu liên quan đến lừa đảo. Cơ quan công an và ngân hàng không bao giờ yêu cầu chuyển tiền vào tài khoản “tạm giữ” hay “xác minh”. Nếu ai đó đang hướng dẫn bạn chuyển khoản, hãy dừng lại.',
  pause: { title: 'Tạm dừng để kiểm tra', sub: 'Giao dịch đang được giữ an toàn trong 30 phút', question: 'Ai đang hướng dẫn bạn chuyển khoản này?' },
  guides: ['Cơ quan nhà nước / công an', 'Nhân viên ngân hàng', 'Người thân trong gia đình', 'Bạn bè', 'Người bán hàng', 'Không ai cả, tôi tự chuyển', 'Khác'] as const,
  chain: { title: 'Xem lại giao dịch gần đây của bạn', summary: 'Bạn vừa rút tiết kiệm và chuyển cho 2 người nhận mới trong 30 phút.', rows: ['08:10  Tất toán sổ tiết kiệm  +200.000.000 đ', '08:25  Chuyển đến TRAN VAN B (mới)  −50.000.000 đ', '08:40  Đang chuyển đến LE THI C (mới)  −120.000.000 đ'] },
  guardian: { pending: 'Đang chờ người thân xác nhận', person: 'Con gái – Nguyễn Thu Hà', sent: 'Đã gửi yêu cầu lúc 09:12', body: 'Tiền của bạn đang được giữ an toàn. Khi người thân xác nhận, giao dịch sẽ tiếp tục.', approve: 'Không, hãy giữ lại', reject: 'Tôi xác nhận, cho chuyển', call: 'Gọi cho mẹ ngay', guardianTitle: 'Xác nhận giao dịch của mẹ', guardianBody: 'Mẹ bạn (Bà Lan) đang chuyển 120.000.000 đ đến tài khoản mới LE THI C. Bà có thể đang được ai đó hướng dẫn qua điện thoại.' },
  wait: { title: 'Chờ một chút', body: 'Hãy gọi lại cho người thân bằng số bạn đã lưu để chắc chắn đúng là họ.', time: '02:00' },
  hangup: { title: 'Hãy cúp máy trước khi tiếp tục', active: 'Đang có cuộc gọi', body: 'Công an, toà án và ngân hàng không bao giờ yêu cầu chuyển tiền qua điện thoại. Kẻ gian thường dặn bạn không được cúp máy.', reasons: ['Bạn đang trong một cuộc gọi', 'Bạn vừa rút tiết kiệm', 'Người nhận là tài khoản mới'], countdown: '09:42', call: 'Gọi cho người thân' },
  held: { title: 'Giao dịch đang được giữ', until: 'Giữ đến 09:12 ngày 21/09', protected: 'Được bảo vệ', refund: 'Huỷ và hoàn tiền', success: 'Đã huỷ – 120.000.000 đ đã được hoàn về tài khoản của bạn' },
  permission: { title: 'Bảo vệ bạn khỏi cuộc gọi lừa đảo', body: 'FIDES chỉ kiểm tra bạn CÓ đang trong cuộc gọi hay không khi bạn chuyển tiền. Chúng tôi không nghe, không ghi âm, không đọc số điện thoại hay tin nhắn.' },
} as const
